import os
import json
from Utils import save_config
from colorama import Fore, Style, init

init(autoreset=True)


def print_header():
    print(Fore.CYAN + "=" * 60)
    print(Fore.CYAN + "🐦 FunPay Cardinal - Первоначальная настройка")
    print(Fore.CYAN + "=" * 60)
    print()


def get_golden_key():
    print(Fore.YELLOW + "📝 Настройка подключения к FunPay")
    print()
    print("Для работы бота необходим Golden Key от вашего аккаунта FunPay.")
    print("Как получить Golden Key:")
    print("1. Зайдите на funpay.com")
    print("2. Откройте DevTools (F12)")
    print("3. Перейдите на вкладку Application > Cookies")
    print("4. Найдите cookie 'golden_key' и скопируйте его значение")
    print()
    
    golden_key = input(Fore.GREEN + "Введите Golden Key: " + Style.RESET_ALL).strip()
    
    if not golden_key:
        print(Fore.RED + "❌ Golden Key не может быть пустым!")
        return get_golden_key()
    
    return golden_key


def get_telegram_token():
    print()
    print(Fore.YELLOW + "🤖 Настройка Telegram бота")
    print()
    print("Для работы бота необходим токен Telegram бота.")
    print("Как получить токен:")
    print("1. Найдите @BotFather в Telegram")
    print("2. Отправьте команду /newbot")
    print("3. Следуйте инструкциям")
    print("4. Скопируйте полученный токен")
    print()
    
    token = input(Fore.GREEN + "Введите Telegram Bot Token: " + Style.RESET_ALL).strip()
    
    if not token:
        print(Fore.RED + "❌ Токен не может быть пустым!")
        return get_telegram_token()
    
    return token


def get_admin_ids():
    print()
    print(Fore.YELLOW + "👥 Настройка администраторов")
    print()
    print("Введите Telegram ID администраторов (через запятую).")
    print("Как узнать свой ID:")
    print("1. Найдите @userinfobot в Telegram")
    print("2. Отправьте ему любое сообщение")
    print("3. Скопируйте ваш ID")
    print()
    
    ids_str = input(Fore.GREEN + "Введите Admin IDs (через запятую): " + Style.RESET_ALL).strip()
    
    if not ids_str:
        print(Fore.RED + "❌ Список админов не может быть пустым!")
        return get_admin_ids()
    
    try:
        admin_ids = [int(id.strip()) for id in ids_str.split(',')]
        return admin_ids
    except ValueError:
        print(Fore.RED + "❌ Неверный формат! Введите числа через запятую.")
        return get_admin_ids()


def run_first_setup():
    if os.path.exists("_config.cfg"):
        print(Fore.YELLOW + "⚠️  Конфигурация уже существует!")
        choice = input("Хотите перезаписать её? (y/n): ").strip().lower()
        if choice != 'y':
            print(Fore.CYAN + "Настройка отменена.")
            return False
    
    print_header()
    
    golden_key = get_golden_key()
    telegram_token = get_telegram_token()
    admin_ids = get_admin_ids()
    
    config = {
        "FunPay": {
            "golden_key": golden_key,
            "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        },
        "Telegram": {
            "token": telegram_token,
            "admin_ids": admin_ids
        },
        "AutoResponse": {
            "enabled": True,
            "greetings": True
        },
        "AutoRaise": {
            "enabled": True,
            "interval": 3600
        },
        "AutoDelivery": {
            "enabled": False
        },
        "Localization": {
            "language": "ru"
        }
    }
    
    save_config(config)
    
    print()
    print(Fore.GREEN + "=" * 60)
    print(Fore.GREEN + "✅ Настройка завершена успешно!")
    print(Fore.GREEN + "=" * 60)
    print()
    print("Теперь вы можете запустить бота командой:")
    print(Fore.CYAN + "python main.py")
    print()
    
    return True


if __name__ == "__main__":
    run_first_setup()
