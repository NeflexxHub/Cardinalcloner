# 🐦 FunPay Cardinal

**Простой и эффективный бот для автоматизации работы продавцов на FunPay**

[![Python](https://img.shields.io/badge/Python-3.11-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

## 📋 Описание

FunPay Cardinal - это мощный Python бот для автоматизации работы на торговой площадке FunPay. Бот предоставляет полный набор инструментов для управления вашими лотами, заказами и общением с покупателями через удобный Telegram интерфейс.

## ✨ Возможности

- ✅ **Авторизация на FunPay** через Golden Key
- 🤖 **Telegram бот** для удобного управления
- 💬 **Автоответы** на сообщения покупателей с настраиваемыми шаблонами
- 🔔 **Уведомления** о новых заказах и сообщениях в Telegram
- ⬆️ **Автоподнятие лотов** по расписанию
- 📊 **Статистика продаж** (количество заказов, сумма, графики)
- 🔌 **Система плагинов** для расширения функциональности
- 👥 **Мультиадминистрирование** (несколько админов Telegram)
- 📦 **Автодоставка товаров** из текстовых файлов
- 🎨 **Цветное логирование** с сохранением в файлы
- 🌍 **Локализация** (русский/украинский языки)

## 🚀 Быстрый старт

### 1. Установка зависимостей

Все зависимости устанавливаются автоматически при запуске на Replit.

### 2. Первый запуск

При первом запуске бота вы увидите мастер первоначальной настройки:

```bash
python main.py
```

Мастер настройки попросит вас ввести:

#### **Golden Key от FunPay:**
1. Зайдите на [funpay.com](https://funpay.com)
2. Откройте DevTools (F12)
3. Перейдите на вкладку Application → Cookies
4. Найдите cookie `golden_key` и скопируйте его значение

#### **Telegram Bot Token:**
1. Найдите [@BotFather](https://t.me/BotFather) в Telegram
2. Отправьте команду `/newbot`
3. Следуйте инструкциям
4. Скопируйте полученный токен

#### **Telegram Admin IDs:**
1. Найдите [@userinfobot](https://t.me/userinfobot) в Telegram
2. Отправьте ему любое сообщение
3. Скопируйте ваш ID
4. Можно указать несколько ID через запятую

### 3. Запуск бота

После настройки бот запустится автоматически. Вы увидите:

```
🐦 FunPay Cardinal запускается...
✅ Авторизация успешна: YourUsername (ID: 123456), баланс: 1000 ₽
✅ Cardinal запущен успешно!
🤖 Telegram бот запущен
```

## ⚙️ Конфигурация

Все настройки хранятся в файле `_config.cfg` (создается автоматически):

```json
{
  "FunPay": {
    "golden_key": "your_golden_key_here",
    "user_agent": "Mozilla/5.0..."
  },
  "Telegram": {
    "token": "your_bot_token_here",
    "admin_ids": [123456789]
  },
  "AutoResponse": {
    "enabled": true,
    "greetings": true
  },
  "AutoRaise": {
    "enabled": true,
    "interval": 3600
  },
  "AutoDelivery": {
    "enabled": false
  },
  "Localization": {
    "language": "ru"
  }
}
```

### Автоответы

Настройте шаблоны автоответов в файле `auto_response.json`:

```json
{
  "greeting": "Здравствуйте! Спасибо за обращение. Чем могу помочь?",
  "order_received": "Заказ принят! Выдача произойдет в ближайшее время.",
  "order_completed": "Заказ выполнен! Спасибо за покупку!",
  "default": "Спасибо за сообщение!"
}
```

### Автодоставка

Для настройки автодоставки:

1. Создайте файл `auto_delivery.txt`
2. Добавьте товары (по одному на строку):
```
PRODUCT-KEY-12345
PRODUCT-KEY-67890
ANOTHER-PRODUCT-KEY
```
3. Включите автодоставку в конфигурации:
```json
"AutoDelivery": {
  "enabled": true
}
```

## 🔌 Плагины

Плагины позволяют расширить функциональность бота. Разместите Python файлы в папке `plugins/`.

### Пример плагина:

```python
import logging

logger = logging.getLogger("Plugin.MyPlugin")

class Plugin:
    def __init__(self, cardinal):
        self.cardinal = cardinal
        self.name = "My Plugin"
        self.version = "1.0.0"
    
    def on_init(self):
        logger.info(f"Плагин {self.name} инициализирован")
    
    def on_message(self, message):
        logger.info(f"Получено сообщение: {message.text}")
    
    def on_order(self, order):
        logger.info(f"Получен заказ #{order.order_id}")
```

⚠️ **Безопасность**: Устанавливайте только проверенные плагины из надежных источников!

## 📱 Telegram команды

- `/start` - Главное меню
- `/help` - Справка по командам
- `/status` - Статус бота
- `/stats` - Статистика продаж
- `/lots` - Список ваших лотов
- `/raise` - Поднять лоты вручную
- `/balance` - Баланс аккаунта

## 📂 Структура проекта

```
FunPayCardinal/
├── FunPayAPI/          # Модуль для работы с FunPay API
│   ├── __init__.py
│   ├── account.py      # Класс аккаунта FunPay
│   ├── types.py        # Типы данных (Message, Order, Lot)
│   └── runner.py       # Основной цикл обработки событий
├── tg_bot/             # Telegram бот
│   ├── __init__.py
│   └── bot.py          # Логика Telegram бота
├── Utils/              # Вспомогательные утилиты
│   ├── __init__.py
│   ├── logger.py       # Система логирования
│   └── config_loader.py # Загрузка конфигурации
├── locales/            # Файлы локализации
│   ├── ru.json         # Русский язык
│   └── uk.json         # Украинский язык
├── plugins/            # Папка для плагинов
│   └── example_plugin.py
├── storage/            # Хранение данных
├── logs/               # Логи работы бота
├── backups/            # Резервные копии
├── main.py             # Точка входа
├── cardinal.py         # Основной класс бота
├── handlers.py         # Обработчики событий
├── first_setup.py      # Первоначальная настройка
├── requirements.txt    # Python зависимости
└── README.md           # Этот файл
```

## 🛠️ Технологии

- **Python 3.11** - основной язык
- **requests** - HTTP запросы к FunPay
- **beautifulsoup4** - парсинг HTML страниц
- **pytelegrambotapi** - Telegram Bot API
- **colorama** - цветной вывод в консоли
- **pillow** - обработка изображений
- **lxml** - быстрый парсинг
- **bcrypt** - хеширование

## 📝 Логирование

Все действия бота логируются:

- В консоль с цветным выводом
- В файлы в папке `logs/` (один файл на день)

Формат: `logs/cardinal_YYYYMMDD.log`

## ⚠️ Важно

- Храните `_config.cfg` в секрете (он содержит ваш Golden Key)
- Регулярно проверяйте логи на наличие ошибок
- Делайте резервные копии конфигурации
- Не передавайте Golden Key третьим лицам

## 🤝 Поддержка

Если у вас возникли вопросы или проблемы:

1. Проверьте логи в папке `logs/`
2. Убедитесь, что Golden Key и Telegram Token корректны
3. Проверьте, что у вас установлены все зависимости

## 📜 Лицензия

MIT License - свободное использование с указанием авторства.

---

**Создано с ❤️ для автоматизации работы на FunPay**
