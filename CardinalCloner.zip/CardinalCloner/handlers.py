import logging
from FunPayAPI import Message, Order
import json
import os
from typing import Dict, List

logger = logging.getLogger("Handlers")


class AutoResponse:
    def __init__(self, config_path: str = "auto_response.json"):
        self.config_path = config_path
        self.templates: Dict[str, str] = self._load_templates()
    
    def _load_templates(self) -> Dict[str, str]:
        if not os.path.exists(self.config_path):
            default_templates = {
                "greeting": "Здравствуйте! Спасибо за обращение. Чем могу помочь?",
                "order_received": "Заказ принят! Выдача произойдет в ближайшее время.",
                "order_completed": "Заказ выполнен! Спасибо за покупку!",
                "default": "Спасибо за сообщение!"
            }
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(default_templates, f, indent=4, ensure_ascii=False)
            return default_templates
        
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Ошибка загрузки шаблонов автоответов: {e}")
            return {}
    
    def get_response(self, message_type: str = "default") -> str:
        return self.templates.get(message_type, self.templates.get("default", ""))


class AutoDelivery:
    def __init__(self, delivery_file: str = "auto_delivery.txt"):
        self.delivery_file = delivery_file
        self.products: List[str] = self._load_products()
    
    def _load_products(self) -> List[str]:
        if not os.path.exists(self.delivery_file):
            with open(self.delivery_file, 'w', encoding='utf-8') as f:
                f.write("# Пример товаров для автовыдачи (один товар на строку)\n")
                f.write("# PRODUCT-KEY-12345\n")
                f.write("# PRODUCT-KEY-67890\n")
            return []
        
        try:
            with open(self.delivery_file, 'r', encoding='utf-8') as f:
                products = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            return products
        except Exception as e:
            logger.error(f"Ошибка загрузки товаров для автовыдачи: {e}")
            return []
    
    def get_product(self) -> str:
        if not self.products:
            return ""
        
        product = self.products.pop(0)
        self._save_products()
        return product
    
    def _save_products(self):
        try:
            with open(self.delivery_file, 'w', encoding='utf-8') as f:
                f.write("# Товары для автовыдачи\n")
                for product in self.products:
                    f.write(f"{product}\n")
        except Exception as e:
            logger.error(f"Ошибка сохранения товаров: {e}")


def on_new_message(message: Message, auto_response: AutoResponse, account):
    logger.info(f"💬 Новое сообщение от {message.author}: {message.text[:50]}...")
    
    if message.author_id != account.user_id:
        response = auto_response.get_response("default")
        if response:
            logger.info(f"🤖 Отправляю автоответ: {response[:50]}...")


def on_new_order(order: Order, auto_delivery: AutoDelivery, telegram_bot):
    logger.info(f"🛒 Новый заказ #{order.order_id} от {order.buyer}: {order.description}")
    
    notification = (
        f"🛒 <b>Новый заказ!</b>\n\n"
        f"📦 Заказ: #{order.order_id}\n"
        f"👤 Покупатель: {order.buyer}\n"
        f"💰 Сумма: {order.price} ₽\n"
        f"📝 Описание: {order.description}"
    )
    
    telegram_bot.send_notification(notification)
    
    if auto_delivery:
        product = auto_delivery.get_product()
        if product:
            logger.info(f"📤 Автовыдача товара: {product}")
