import json
import os
import logging
from typing import Dict, Any

logger = logging.getLogger("Config")


def load_config(config_path: str = "_config.cfg") -> Dict[str, Any]:
    if not os.path.exists(config_path):
        logger.warning(f"Файл конфигурации {config_path} не найден, создаю дефолтный")
        default_config = {
            "FunPay": {
                "golden_key": "",
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            },
            "Telegram": {
                "token": "",
                "admin_ids": []
            },
            "AutoResponse": {
                "enabled": True,
                "greetings": True
            },
            "AutoRaise": {
                "enabled": True,
                "interval": 3600
            },
            "AutoDelivery": {
                "enabled": False
            },
            "Localization": {
                "language": "ru"
            }
        }
        save_config(default_config, config_path)
        return default_config
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        logger.info(f"✅ Конфигурация загружена из {config_path}")
        return config
    except Exception as e:
        logger.error(f"❌ Ошибка загрузки конфигурации: {e}")
        return {}


def save_config(config: Dict[str, Any], config_path: str = "_config.cfg"):
    try:
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        logger.info(f"✅ Конфигурация сохранена в {config_path}")
    except Exception as e:
        logger.error(f"❌ Ошибка сохранения конфигурации: {e}")
