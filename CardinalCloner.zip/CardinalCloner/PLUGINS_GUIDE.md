# 🔌 Руководство по плагинам FunPayCardinal

## Что такое плагины?

Плагины позволяют расширить функциональность бота без изменения основного кода. Вы можете создавать свои собственные обработчики событий, добавлять новые команды Telegram и автоматизировать любые действия.

## Структура плагина

Каждый плагин - это Python файл в папке `plugins/` с классом `Plugin`:

```python
import logging

logger = logging.getLogger("Plugin.MyPlugin")

class Plugin:
    def __init__(self, cardinal):
        """
        Инициализация плагина
        cardinal - главный объект бота со всеми компонентами
        """
        self.cardinal = cardinal
        self.name = "My Plugin"
        self.version = "1.0.0"
        self.description = "Описание плагина"
        
        logger.info(f"🔌 Плагин '{self.name}' v{self.version} загружен")
    
    def on_init(self):
        """Вызывается при инициализации плагина"""
        logger.info(f"✅ Плагин '{self.name}' инициализирован")
    
    def on_message(self, message):
        """Вызывается при получении нового сообщения"""
        logger.info(f"📨 Получено сообщение: {message.text}")
    
    def on_order(self, order):
        """Вызывается при получении нового заказа"""
        logger.info(f"📦 Получен заказ #{order.order_id}")
    
    def on_shutdown(self):
        """Вызывается при остановке бота"""
        logger.info(f"⛔ Плагин '{self.name}' выгружается")
```

## Hooks (события)

### 1. `on_init()`
Вызывается один раз при запуске бота

**Пример:** Загрузка конфигурации плагина
```python
def on_init(self):
    self.config = self.load_plugin_config()
    logger.info("Конфигурация загружена")
```

### 2. `on_message(message)`
Вызывается при каждом новом сообщении от покупателя

**Параметры:**
- `message.text` - текст сообщения
- `message.author` - имя отправителя
- `message.author_id` - ID отправителя
- `message.chat_id` - ID чата
- `message.timestamp` - время отправки

**Пример:** Автоответ на ключевые слова
```python
def on_message(self, message):
    if "скидка" in message.text.lower():
        self.cardinal.account.send_message(
            message.chat_id,
            "К сожалению, скидок сейчас нет 😔"
        )
```

### 3. `on_order(order)`
Вызывается при каждом новом заказе

**Параметры:**
- `order.order_id` - ID заказа
- `order.buyer` - имя покупателя
- `order.buyer_id` - ID покупателя
- `order.description` - описание заказа
- `order.price` - сумма заказа
- `order.status` - статус заказа

**Пример:** Уведомление в Telegram с деталями
```python
def on_order(self, order):
    notification = f"""
🎉 НОВЫЙ ЗАКАЗ!
ID: #{order.order_id}
Покупатель: {order.buyer}
Сумма: {order.price} ₽
Товар: {order.description}
"""
    self.cardinal.telegram_bot.send_notification(notification)
```

### 4. `on_shutdown()`
Вызывается при остановке бота

**Пример:** Сохранение данных перед выключением
```python
def on_shutdown(self):
    self.save_statistics()
    logger.info("Данные сохранены")
```

## Доступ к компонентам бота

Через `self.cardinal` вы можете получить доступ ко всем компонентам:

### FunPay аккаунт
```python
# Информация об аккаунте
username = self.cardinal.account.username
user_id = self.cardinal.account.user_id
balance = self.cardinal.account.balance

# Получить лоты
lots = self.cardinal.account.get_lots()

# Поднять лоты
self.cardinal.account.raise_lots()

# Отправить сообщение
self.cardinal.account.send_message(chat_id, "Текст")

# Получить заказы
orders = self.cardinal.account.get_orders()
```

### Telegram бот
```python
# Отправить уведомление всем админам
self.cardinal.telegram_bot.send_notification("Текст")

# Доступ к самому боту telebot
bot = self.cardinal.telegram_bot.bot
```

### Конфигурация
```python
# Получить настройки
config = self.cardinal.config

# Автоответы
auto_response = self.cardinal.auto_response
template = auto_response.get_response("greeting")

# Автодоставка
if self.cardinal.auto_delivery:
    product = self.cardinal.auto_delivery.get_product()
```

## Примеры плагинов

### 1. Статистика продаж
```python
import logging
import json
from datetime import datetime

logger = logging.getLogger("Plugin.Statistics")

class Plugin:
    def __init__(self, cardinal):
        self.cardinal = cardinal
        self.name = "Sales Statistics"
        self.version = "1.0.0"
        
        self.stats = {
            "total_orders": 0,
            "total_revenue": 0.0,
            "orders_today": 0
        }
    
    def on_init(self):
        # Загрузить сохраненную статистику
        try:
            with open("storage/stats.json", "r") as f:
                self.stats = json.load(f)
        except:
            pass
    
    def on_order(self, order):
        # Обновить статистику
        self.stats["total_orders"] += 1
        self.stats["total_revenue"] += order.price
        self.stats["orders_today"] += 1
        
        # Сохранить
        with open("storage/stats.json", "w") as f:
            json.dump(self.stats, f, indent=4)
        
        logger.info(f"📊 Всего заказов: {self.stats['total_orders']}, "
                   f"Выручка: {self.stats['total_revenue']} ₽")
    
    def on_shutdown(self):
        # Сохранить перед выходом
        with open("storage/stats.json", "w") as f:
            json.dump(self.stats, f, indent=4)
```

### 2. Автоматическое приветствие новых покупателей
```python
import logging

logger = logging.getLogger("Plugin.AutoGreeting")

class Plugin:
    def __init__(self, cardinal):
        self.cardinal = cardinal
        self.name = "Auto Greeting"
        self.greeted_users = set()
    
    def on_message(self, message):
        # Если это первое сообщение от пользователя
        if message.author_id not in self.greeted_users:
            greeting = f"""
Здравствуйте, {message.author}! 👋

Спасибо, что обратились к нам!
Мы всегда на связи и готовы помочь.

Чем могу быть полезен?
"""
            self.cardinal.account.send_message(message.chat_id, greeting)
            self.greeted_users.add(message.author_id)
            logger.info(f"✉️ Отправлено приветствие пользователю {message.author}")
```

### 3. Уведомления о крупных заказах
```python
import logging

logger = logging.getLogger("Plugin.BigOrders")

class Plugin:
    def __init__(self, cardinal):
        self.cardinal = cardinal
        self.name = "Big Orders Alert"
        self.threshold = 1000  # Порог в рублях
    
    def on_order(self, order):
        if order.price >= self.threshold:
            alert = f"""
🔥 КРУПНЫЙ ЗАКАЗ!

💰 Сумма: {order.price} ₽
👤 Покупатель: {order.buyer}
📦 Заказ: #{order.order_id}

Требуется особое внимание!
"""
            self.cardinal.telegram_bot.send_notification(alert)
            logger.info(f"🔥 Крупный заказ: {order.price} ₽")
```

### 4. Автоматический перевод сообщений
```python
import logging

logger = logging.getLogger("Plugin.AutoTranslate")

class Plugin:
    def __init__(self, cardinal):
        self.cardinal = cardinal
        self.name = "Auto Translate"
    
    def detect_language(self, text):
        # Простая проверка на английский
        english_chars = sum(1 for c in text if ord(c) < 128)
        return "en" if english_chars / len(text) > 0.5 else "ru"
    
    def on_message(self, message):
        lang = self.detect_language(message.text)
        
        if lang == "en":
            # Отправить автоответ на английском
            response = "Hello! Unfortunately, I only speak Russian. "
            response += "Please use a translator. Thank you!"
            
            self.cardinal.account.send_message(message.chat_id, response)
            
            # Уведомить админа
            self.cardinal.telegram_bot.send_notification(
                f"⚠️ Сообщение на английском от {message.author}:\n{message.text}"
            )
```

## Установка плагина

1. Создайте файл `plugins/your_plugin.py`
2. Напишите класс `Plugin` с нужными методами
3. Перезапустите бота

**Плагин загрузится автоматически!**

## Отключение плагина

Просто удалите или переименуйте файл плагина (например, добавьте `.disabled`):

```bash
mv plugins/my_plugin.py plugins/my_plugin.py.disabled
```

## ⚠️ Важно для безопасности

1. **Устанавливайте только проверенные плагины** из надежных источников
2. Плагины имеют **полный доступ** к вашему аккаунту FunPay
3. Проверяйте код плагина перед установкой
4. Не передавайте плагинам свои секретные данные

## Дополнительные возможности

### Создание собственных команд Telegram

```python
class Plugin:
    def on_init(self):
        # Добавить обработчик команды
        @self.cardinal.telegram_bot.bot.message_handler(commands=['mystats'])
        def handle_mystats(message):
            stats_text = f"📊 Статистика плагина:\n{self.get_stats()}"
            self.cardinal.telegram_bot.bot.reply_to(message, stats_text)
```

### Работа с базой данных

```python
import sqlite3

class Plugin:
    def on_init(self):
        # Создать БД для плагина
        self.db = sqlite3.connect('storage/myplugin.db')
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY,
                order_id TEXT,
                price REAL,
                timestamp DATETIME
            )
        """)
    
    def on_order(self, order):
        # Сохранить в БД
        self.db.execute(
            "INSERT INTO orders (order_id, price, timestamp) VALUES (?, ?, ?)",
            (order.order_id, order.price, order.timestamp)
        )
        self.db.commit()
```

## Поддержка

Если у вас возникли вопросы по созданию плагинов:
1. Изучите примеры в `plugins/example_plugin.py`
2. Проверьте логи в `logs/`
3. Используйте `logger.info()` для отладки

---

**Удачи в создании плагинов!** 🚀
