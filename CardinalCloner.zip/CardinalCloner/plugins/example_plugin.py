import logging

logger = logging.getLogger("Plugin.Example")


class Plugin:
    def __init__(self, cardinal):
        self.cardinal = cardinal
        self.name = "Example Plugin"
        self.version = "1.0.0"
        self.description = "Пример плагина для FunPay Cardinal"
        
        logger.info(f"🔌 Плагин '{self.name}' v{self.version} загружен")
    
    def on_init(self):
        logger.info(f"✅ Плагин '{self.name}' инициализирован")
    
    def on_message(self, message):
        logger.debug(f"📨 Плагин обработал сообщение: {message.text[:30]}...")
    
    def on_order(self, order):
        logger.info(f"📦 Плагин обработал заказ #{order.order_id}")
    
    def on_shutdown(self):
        logger.info(f"⛔ Плагин '{self.name}' выгружен")
