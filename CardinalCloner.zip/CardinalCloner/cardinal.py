import logging
import time
from threading import Thread
from FunPayAPI import Account, Runner
from tg_bot import CardinalTelegramBot
from handlers import AutoResponse, AutoDelivery, on_new_message, on_new_order
from Utils import load_config
import os
import importlib.util
from pathlib import Path

logger = logging.getLogger("Cardinal")


class Cardinal:
    def __init__(self):
        self.config = load_config()
        
        golden_key = self.config.get("FunPay", {}).get("golden_key", "")
        if not golden_key:
            raise ValueError("❌ Golden Key не найден в конфигурации!")
        
        user_agent = self.config.get("FunPay", {}).get("user_agent")
        self.account = Account(golden_key, user_agent)
        
        if not self.account.authorize():
            raise ValueError("❌ Не удалось авторизоваться на FunPay!")
        
        token = self.config.get("Telegram", {}).get("token", "")
        admin_ids = self.config.get("Telegram", {}).get("admin_ids", [])
        
        if not token:
            raise ValueError("❌ Telegram токен не найден в конфигурации!")
        
        if not admin_ids:
            logger.warning("⚠️ Список админов Telegram пуст. Некоторые функции недоступны.")
        
        self.telegram_bot = CardinalTelegramBot(token, admin_ids, cardinal=self)
        self.telegram = self.telegram_bot  # Для совместимости с плагинами
        
        self.runner = Runner(self.account, delay=5)
        
        self.demo_mode = not self.account._is_authorized or self.account.user_id == 999999
        
        self.auto_response = AutoResponse()
        self.auto_delivery = AutoDelivery() if self.config.get("AutoDelivery", {}).get("enabled") else None
        
        self.auto_raise_enabled = self.config.get("AutoRaise", {}).get("enabled", True)
        self.auto_raise_interval = self.config.get("AutoRaise", {}).get("interval", 3600)
        self.last_raise_time = 0
        
        self.plugins = []
        self._load_plugins()
        
        self._setup_handlers()
    
    def _load_plugins(self):
        """Загружает все плагины из папки plugins/"""
        plugins_dir = Path("plugins")
        if not plugins_dir.exists():
            plugins_dir.mkdir(exist_ok=True)
            return
        
        for plugin_file in plugins_dir.glob("*.py"):
            if plugin_file.name.startswith("_") or plugin_file.name == "example_plugin.py":
                continue
            
            try:
                spec = importlib.util.spec_from_file_location(plugin_file.stem, plugin_file)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                # Если плагин имеет функцию init_commands, вызываем её
                if hasattr(module, "init_commands"):
                    module.init_commands(self)
                    logger.info(f"✅ Плагин '{plugin_file.name}' инициализирован")
                
                self.plugins.append(module)
                
            except Exception as e:
                logger.error(f"❌ Ошибка при загрузке плагина '{plugin_file.name}': {e}")
                logger.debug("TRACEBACK", exc_info=True)
    
    def _setup_handlers(self):
        self.runner.add_message_handler(
            lambda msg: on_new_message(msg, self.auto_response, self.account)
        )
        
        def order_handler(order):
            if self.auto_delivery:
                on_new_order(order, self.auto_delivery, self.telegram_bot)
            else:
                logger.info(f"🛒 Новый заказ #{order.order_id} от {order.buyer}")
        
        self.runner.add_order_handler(order_handler)
    
    def _auto_raise_loop(self):
        logger.info("🔄 Запущен цикл автоподнятия лотов")
        
        while True:
            try:
                current_time = time.time()
                
                if current_time - self.last_raise_time >= self.auto_raise_interval:
                    logger.info("⬆️ Выполняю автоподнятие лотов...")
                    if self.account.raise_lots():
                        self.last_raise_time = current_time
                        logger.info("✅ Лоты подняты успешно")
                    else:
                        logger.warning("⚠️ Не удалось поднять лоты")
                
                time.sleep(60)
                
            except Exception as e:
                logger.error(f"❌ Ошибка в цикле автоподнятия: {e}")
                time.sleep(60)
    
    def start(self):
        logger.info("=" * 60)
        logger.info("🐦 FunPay Cardinal запускается...")
        logger.info("=" * 60)
        
        if self.demo_mode:
            logger.warning("⚠️ РЕЖИМ ДЕМО - функционал FunPay отключен")
            logger.info("📝 Для полной работы обновите _config.cfg с правильным Golden Key")
        
        logger.info(f"👤 Аккаунт: {self.account.username} (ID: {self.account.user_id})")
        logger.info(f"💰 Баланс: {self.account.balance} {self.account.currency}")
        
        if not self.demo_mode:
            self.runner.start()
            
            if self.auto_raise_enabled:
                raise_thread = Thread(target=self._auto_raise_loop, daemon=True)
                raise_thread.start()
                logger.info("✅ Автоподнятие лотов включено")
        
        logger.info("✅ Cardinal запущен успешно!")
        logger.info("=" * 60)
        
        self.telegram_bot.start_polling()
    
    def add_telegram_commands(self, plugin_uuid: str, commands: list):
        """Регистрировать команды плагина (для совместимости)"""
        logger.info(f"📝 Команды плагина {plugin_uuid} зарегистрированы: {[cmd[0] for cmd in commands]}")
    
    def stop(self):
        logger.info("⛔ Остановка Cardinal...")
        self.runner.stop()
        self.telegram_bot.stop_polling()
        logger.info("✅ Cardinal остановлен")
