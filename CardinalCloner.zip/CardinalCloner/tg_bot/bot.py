import telebot
from telebot import types
import logging
from typing import List, Optional, Callable
import json
import os

logger = logging.getLogger("TelegramBot")


class CardinalTelegramBot:
    def __init__(self, token: str, admin_ids: List[int], cardinal=None):
        self.token = token
        self.admin_ids = admin_ids
        self.cardinal = cardinal
        self.bot = telebot.TeleBot(token, parse_mode='HTML')
        
        # Система управления состояниями пользователей
        self.user_states = {}  # {chat_id: {user_id: state}}
        
        self._setup_handlers()
    
    def _is_admin(self, user_id: int) -> bool:
        if not self.admin_ids:
            logger.warning(f"⚠️ Список админов пуст, разрешаю доступ для ID {user_id}")
            return True
        return user_id in self.admin_ids
    
    def set_state(self, chat_id: int, message_id: int, user_id: int, state: str):
        """Установить состояние пользователя"""
        if chat_id not in self.user_states:
            self.user_states[chat_id] = {}
        self.user_states[chat_id][user_id] = state
        logger.debug(f"📝 Установлено состояние {state} для пользователя {user_id} в чате {chat_id}")
    
    def clear_state(self, chat_id: int, user_id: int, delete_message: bool = False):
        """Очистить состояние пользователя"""
        if chat_id in self.user_states and user_id in self.user_states[chat_id]:
            del self.user_states[chat_id][user_id]
        logger.debug(f"🧹 Очищено состояние для пользователя {user_id} в чате {chat_id}")
    
    def check_state(self, chat_id: int, user_id: int, state: str) -> bool:
        """Проверить состояние пользователя"""
        if chat_id in self.user_states:
            return self.user_states[chat_id].get(user_id) == state
        return False
    
    def msg_handler(self, callback, commands=None, func=None):
        """Регистрировать обработчик сообщений (совместимость с плагинами)"""
        if commands:
            self.bot.message_handler(commands=commands)(callback)
        elif func:
            self.bot.message_handler(func=func)(callback)
        else:
            self.bot.message_handler()(callback)
    
    def file_handler(self, state_name: str, callback):
        """Обработчик файлов (совместимость с плагинами)"""
        def file_processor(message):
            if self.check_state(message.chat.id, message.from_user.id, state_name):
                callback(message)
        
        self.bot.message_handler(content_types=['document'])(file_processor)
    
    def _setup_handlers(self):
        @self.bot.message_handler(commands=['start'])
        def start_handler(message):
            if not self._is_admin(message.from_user.id):
                self.bot.reply_to(message, "❌ У вас нет доступа к этому боту.")
                return
            
            keyboard = self._get_main_keyboard()
            self.bot.send_message(
                message.chat.id,
                "🐦 <b>FunPay Cardinal</b>\n\n"
                "Добро пожаловать в панель управления ботом!\n\n"
                "Выберите нужное действие:",
                reply_markup=keyboard
            )
        
        @self.bot.message_handler(commands=['help'])
        def help_handler(message):
            if not self._is_admin(message.from_user.id):
                return
            
            help_text = (
                "📚 <b>Доступные команды:</b>\n\n"
                "/start - Главное меню\n"
                "/help - Справка\n"
                "/status - Статус бота\n"
                "/stats - Статистика продаж\n"
                "/lots - Список лотов\n"
                "/raise - Поднять лоты\n"
                "/balance - Баланс аккаунта\n"
            )
            self.bot.send_message(message.chat.id, help_text)
        
        @self.bot.message_handler(commands=['status'])
        def status_handler(message):
            if not self._is_admin(message.from_user.id):
                return
            
            if self.cardinal:
                account = self.cardinal.account
                status_text = f"""
✅ <b>Бот активен и работает</b>

👤 Аккаунт: {account.username}
🆔 ID: {account.user_id}
💰 Баланс: {account.balance} {account.currency}
🔄 Автоподнятие: {'✅ Включено' if self.cardinal.auto_raise_enabled else '❌ Выключено'}
"""
            else:
                status_text = "✅ Бот активен и работает"
            
            self.bot.send_message(message.chat.id, status_text)
        
        @self.bot.message_handler(func=lambda message: message.text == "📊 Статистика")
        def stats_button_handler(message):
            if not self._is_admin(message.from_user.id):
                return
            
            stats_text = "📊 <b>Статистика</b>\n\n"
            
            if self.cardinal:
                account = self.cardinal.account
                stats_text += f"👤 Аккаунт: {account.username}\n"
                stats_text += f"💰 Баланс: {account.balance} {account.currency}\n"
                stats_text += f"🆔 ID: {account.user_id}\n\n"
                stats_text += "📦 Всего заказов: 0\n"
                stats_text += "💵 Общая сумма: 0 ₽\n"
                stats_text += "📅 Сегодня: 0 заказов"
            else:
                stats_text += "Всего заказов: 0\n"
                stats_text += "Общая сумма: 0 ₽\n"
                stats_text += "Сегодня: 0 заказов"
            
            self.bot.send_message(message.chat.id, stats_text)
        
        @self.bot.message_handler(func=lambda message: message.text == "📦 Мои лоты")
        def lots_button_handler(message):
            if not self._is_admin(message.from_user.id):
                return
            
            if self.cardinal:
                lots = self.cardinal.account.get_lots()
                
                if lots:
                    lots_text = "📦 <b>Мои лоты</b>\n\n"
                    for i, lot in enumerate(lots[:10], 1):  # Показываем первые 10
                        lots_text += f"{i}. {lot.title}\n"
                        lots_text += f"   💰 Цена: {lot.price} ₽\n"
                        lots_text += f"   🆔 ID: {lot.lot_id}\n\n"
                    
                    if len(lots) > 10:
                        lots_text += f"... и еще {len(lots) - 10} лотов"
                else:
                    lots_text = "📦 <b>Мои лоты</b>\n\nУ вас пока нет активных лотов"
            else:
                lots_text = "📦 <b>Мои лоты</b>\n\nЗагрузка списка лотов..."
            
            self.bot.send_message(message.chat.id, lots_text)
        
        @self.bot.message_handler(func=lambda message: message.text == "⬆️ Поднять лоты")
        def raise_button_handler(message):
            if not self._is_admin(message.from_user.id):
                return
            
            if self.cardinal:
                self.bot.send_message(message.chat.id, "⬆️ Поднимаю лоты...")
                
                success = self.cardinal.account.raise_lots()
                
                if success:
                    self.bot.send_message(message.chat.id, "✅ Лоты успешно подняты!")
                else:
                    self.bot.send_message(message.chat.id, "❌ Не удалось поднять лоты. Проверьте логи.")
            else:
                self.bot.send_message(message.chat.id, "⬆️ Поднимаю лоты...")
        
        @self.bot.message_handler(func=lambda message: message.text == "💰 Баланс")
        def balance_button_handler(message):
            if not self._is_admin(message.from_user.id):
                return
            
            if self.cardinal:
                account = self.cardinal.account
                balance_text = f"""
💰 <b>Баланс аккаунта</b>

👤 Пользователь: {account.username}
🆔 ID: {account.user_id}
💵 Баланс: {account.balance} {account.currency}
"""
            else:
                balance_text = "💰 <b>Баланс аккаунта</b>\n\nЗагрузка..."
            
            self.bot.send_message(message.chat.id, balance_text)
        
        @self.bot.message_handler(func=lambda message: message.text == "⚙️ Настройки")
        def settings_button_handler(message):
            if not self._is_admin(message.from_user.id):
                return
            
            keyboard = types.InlineKeyboardMarkup()
            keyboard.row(
                types.InlineKeyboardButton("✏️ Автоответы", callback_data="settings_autoresponse"),
                types.InlineKeyboardButton("📤 Автовыдача", callback_data="settings_autodelivery")
            )
            keyboard.row(
                types.InlineKeyboardButton("🔙 Назад", callback_data="back_main")
            )
            
            self.bot.send_message(
                message.chat.id,
                "⚙️ <b>Настройки</b>\n\n"
                "Выберите раздел:",
                reply_markup=keyboard
            )
        
        @self.bot.callback_query_handler(func=lambda call: True)
        def callback_handler(call):
            if not self._is_admin(call.from_user.id):
                return
            
            if call.data == "back_main":
                self.bot.delete_message(call.message.chat.id, call.message.message_id)
                keyboard = self._get_main_keyboard()
                self.bot.send_message(
                    call.message.chat.id,
                    "🐦 <b>FunPay Cardinal</b>\n\nВыберите нужное действие:",
                    reply_markup=keyboard
                )
            
            self.bot.answer_callback_query(call.id)
    
    def _get_main_keyboard(self):
        keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
        keyboard.add(
            types.KeyboardButton("📊 Статистика"),
            types.KeyboardButton("📦 Мои лоты")
        )
        keyboard.add(
            types.KeyboardButton("⬆️ Поднять лоты"),
            types.KeyboardButton("💰 Баланс")
        )
        keyboard.add(
            types.KeyboardButton("⚙️ Настройки")
        )
        return keyboard
    
    def send_notification(self, text: str):
        for admin_id in self.admin_ids:
            try:
                self.bot.send_message(admin_id, text)
            except Exception as e:
                logger.error(f"Ошибка отправки уведомления админу {admin_id}: {e}")
    
    def start_polling(self):
        logger.info("🤖 Telegram бот запущен")
        try:
            self.bot.infinity_polling(timeout=60, long_polling_timeout=60)
        except Exception as e:
            logger.error(f"Ошибка в Telegram боте: {e}")
    
    def stop_polling(self):
        self.bot.stop_polling()
        logger.info("🛑 Telegram бот остановлен")
