"""Статические клавиатуры для Telegram бота"""

from telebot import types

def CLEAR_STATE_BTN():
    """Кнопка для очистки состояния"""
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(types.KeyboardButton("❌ Отмена"))
    return markup
