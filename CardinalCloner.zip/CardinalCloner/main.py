import os
import sys
from Utils import init_logger
from cardinal import Cardinal
from first_setup import run_first_setup

logger = init_logger("Main")


def main():
    logger.info("🚀 Запуск FunPay Cardinal...")
    
    if not os.path.exists("_config.cfg"):
        logger.warning("⚠️  Конфигурация не найдена. Запуск первоначальной настройки...")
        if not run_first_setup():
            logger.error("❌ Первоначальная настройка не завершена. Выход.")
            return
    
    try:
        cardinal = Cardinal()
        cardinal.start()
    except KeyboardInterrupt:
        logger.info("\n⛔ Получен сигнал остановки (Ctrl+C)")
        sys.exit(0)
    except Exception as e:
        logger.error(f"❌ Критическая ошибка: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
