from __future__ import annotations
from typing import Optional, List
from datetime import datetime


class Message:
    def __init__(self, text: str, author: str, author_id: int, chat_id: int, 
                 message_id: Optional[int] = None, timestamp: Optional[datetime] = None):
        self.text = text
        self.author = author
        self.author_id = author_id
        self.chat_id = chat_id
        self.message_id = message_id
        self.timestamp = timestamp or datetime.now()
    
    def __repr__(self):
        return f"Message(author={self.author}, text={self.text[:30]}...)"


class Order:
    def __init__(self, order_id: str, buyer: str, buyer_id: int, 
                 description: str, price: float, status: str = "new"):
        self.order_id = order_id
        self.buyer = buyer
        self.buyer_id = buyer_id
        self.description = description
        self.price = price
        self.status = status
        self.timestamp = datetime.now()
    
    def __repr__(self):
        return f"Order(id={self.order_id}, buyer={self.buyer}, price={self.price})"


class Lot:
    def __init__(self, lot_id: int, title: str, game: str, server: str, 
                 description: str, price: float, amount: int = 0):
        self.lot_id = lot_id
        self.title = title
        self.game = game
        self.server = server
        self.description = description
        self.price = price
        self.amount = amount
        self.active = True
    
    def __repr__(self):
        return f"Lot(id={self.lot_id}, title={self.title}, price={self.price})"


class Category:
    def __init__(self, category_id: int, name: str, game: str):
        self.category_id = category_id
        self.name = name
        self.game = game
        self.lots: List[Lot] = []
    
    def __repr__(self):
        return f"Category(id={self.category_id}, name={self.name}, game={self.game})"


class LotFields:
    """Представление полей лота для редактирования"""
    def __init__(self, lot_id: int, fields: dict = None):
        self.lot_id = lot_id
        self.fields = fields or {}
    
    def set_fields(self, fields: dict):
        """Установить поля лота"""
        self.fields = fields
    
    def __repr__(self):
        return f"LotFields(id={self.lot_id}, fields={len(self.fields)} items)"
