import time
import logging
from typing import Callable, List, Optional
from threading import Thread
from .account import Account
from .types import Message, Order

logger = logging.getLogger("FunPayAPI.Runner")


class Runner:
    def __init__(self, account: Account, delay: int = 5):
        self.account = account
        self.delay = delay
        self.running = False
        
        self._message_handlers: List[Callable] = []
        self._order_handlers: List[Callable] = []
        
        self._last_messages: List[Message] = []
        self._last_orders: List[Order] = []
        
        self._thread: Optional[Thread] = None
    
    def add_message_handler(self, handler: Callable):
        self._message_handlers.append(handler)
    
    def add_order_handler(self, handler: Callable):
        self._order_handlers.append(handler)
    
    def _check_new_messages(self):
        try:
            current_messages = self.account.get_messages()
            
            for msg in current_messages:
                is_new = True
                for old_msg in self._last_messages:
                    if (msg.text == old_msg.text and 
                        msg.author == old_msg.author and 
                        msg.chat_id == old_msg.chat_id):
                        is_new = False
                        break
                
                if is_new:
                    for handler in self._message_handlers:
                        try:
                            handler(msg)
                        except Exception as e:
                            logger.error(f"Ошибка в обработчике сообщений: {e}")
            
            self._last_messages = current_messages
            
        except Exception as e:
            logger.error(f"Ошибка проверки сообщений: {e}")
    
    def _check_new_orders(self):
        try:
            current_orders = self.account.get_orders()
            
            for order in current_orders:
                is_new = True
                for old_order in self._last_orders:
                    if order.order_id == old_order.order_id:
                        is_new = False
                        break
                
                if is_new:
                    for handler in self._order_handlers:
                        try:
                            handler(order)
                        except Exception as e:
                            logger.error(f"Ошибка в обработчике заказов: {e}")
            
            self._last_orders = current_orders
            
        except Exception as e:
            logger.error(f"Ошибка проверки заказов: {e}")
    
    def _run_loop(self):
        logger.info("🔄 Запущен основной цикл Runner")
        
        while self.running:
            try:
                self._check_new_messages()
                self._check_new_orders()
                time.sleep(self.delay)
            except Exception as e:
                logger.error(f"Ошибка в основном цикле: {e}")
                time.sleep(self.delay)
    
    def start(self):
        if self.running:
            logger.warning("Runner уже запущен")
            return
        
        self.running = True
        self._thread = Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        logger.info("✅ Runner запущен")
    
    def stop(self):
        if not self.running:
            logger.warning("Runner не запущен")
            return
        
        self.running = False
        if self._thread:
            self._thread.join(timeout=10)
        logger.info("⛔ Runner остановлен")
