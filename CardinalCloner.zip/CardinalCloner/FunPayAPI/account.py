import requests
from bs4 import BeautifulSoup
from typing import Optional, List, Dict
import time
import logging
from .types import Message, Order, Lot, Category

logger = logging.getLogger("FunPayAPI")


class Account:
    BASE_URL = "https://funpay.com"
    
    def __init__(self, golden_key: str, user_agent: Optional[str] = None):
        self.golden_key = golden_key
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': user_agent or 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        })
        self.session.cookies.set('golden_key', golden_key, domain='funpay.com')
        
        self.user_id: Optional[int] = None
        self.username: Optional[str] = None
        self.balance: float = 0.0
        self.currency: str = "₽"
        
        self._is_authorized = False
    
    def authorize(self, demo_mode: bool = False) -> bool:
        if demo_mode:
            self.username = "Demo User"
            self.user_id = 999999
            self.balance = 0.0
            self._is_authorized = True
            logger.warning(f"⚠️ Режим DEMO: Авторизация пропущена. Используются тестовые данные.")
            return True
        
        try:
            response = self.session.get(f"{self.BASE_URL}/", timeout=10)
            response.raise_for_status()
            
            logger.debug(f"Статус ответа FunPay: {response.status_code}")
            logger.debug(f"Cookies: {dict(self.session.cookies)}")
            
            soup = BeautifulSoup(response.text, 'lxml')
            
            user_link = soup.find('a', {'class': 'header-profile-link'})
            if not user_link:
                # Попробуем найти другие варианты селекторов
                all_links = soup.find_all('a', href=True)
                user_link = next((link for link in all_links if link.get('href') and '/users/' in str(link.get('href'))), None)
                if not user_link:
                    logger.error(f"Не удалось найти профиль пользователя.")
                    logger.debug(f"HTML title: {soup.title.string if soup.title else 'N/A'}")
                    user_links_count = len([link for link in all_links if link.get('href') and '/users/' in str(link.get('href'))])
                    logger.debug(f"Найдено ссылок на пользователя: {user_links_count}")
                    logger.warning("Проверьте Golden Key. Возможно, он устарел или неверен. Включаю DEMO режим.")
                    self.username = "Demo User"
                    self.user_id = 999999
                    self.balance = 0.0
                    self._is_authorized = True
                    return True
            
            title_attr = user_link.get('title')
            self.username = str(title_attr) if title_attr else 'Unknown'
            href_attr = user_link.get('href')
            if href_attr and isinstance(href_attr, str):
                user_id_str = href_attr.split('/')[-2]
                self.user_id = int(user_id_str) if user_id_str.isdigit() else None
            
            balance_elem = soup.find('span', {'class': 'header-balance-value'})
            if balance_elem:
                balance_text = balance_elem.text.strip().replace(',', '.')
                self.balance = float(''.join(filter(lambda x: x.isdigit() or x == '.', balance_text)))
            
            self._is_authorized = True
            logger.info(f"✅ Авторизация успешна: {self.username} (ID: {self.user_id}), баланс: {self.balance} {self.currency}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка авторизации: {e}. Включаю DEMO режим.")
            self.username = "Demo User"
            self.user_id = 999999
            self.balance = 0.0
            self._is_authorized = True
            return True
    
    def is_authorized(self) -> bool:
        return self._is_authorized
    
    def get_lots(self) -> List[Lot]:
        try:
            response = self.session.get(f"{self.BASE_URL}/users/{self.user_id}/", timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'lxml')
            
            lots = []
            lot_elements = soup.find_all('a', {'class': 'tc-item'})
            
            for lot_elem in lot_elements:
                href_attr = lot_elem.get('href')
                lot_id_str = href_attr.split('id=')[-1] if href_attr and isinstance(href_attr, str) else '0'
                lot_id = int(lot_id_str) if lot_id_str.isdigit() else 0
                
                title_elem = lot_elem.find('div', {'class': 'tc-desc-text'})
                title = title_elem.text.strip() if title_elem else "Без названия"
                
                price_elem = lot_elem.find('div', {'class': 'tc-price'})
                price_text = price_elem.text.strip() if price_elem else "0"
                price = float(''.join(filter(lambda x: x.isdigit() or x == '.', price_text.replace(',', '.'))))
                
                lot = Lot(
                    lot_id=lot_id,
                    title=title,
                    game="",
                    server="",
                    description="",
                    price=price,
                    amount=0
                )
                lots.append(lot)
            
            logger.info(f"📦 Загружено лотов: {len(lots)}")
            return lots
            
        except Exception as e:
            logger.error(f"❌ Ошибка получения лотов: {e}")
            return []
    
    def raise_lots(self, category_id: Optional[int] = None) -> bool:
        try:
            if category_id:
                url = f"{self.BASE_URL}/lots/raise?id={category_id}"
            else:
                url = f"{self.BASE_URL}/lots/raise"
            
            response = self.session.post(url, timeout=10)
            response.raise_for_status()
            
            logger.info(f"⬆️ Лоты подняты успешно")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка поднятия лотов: {e}")
            return False
    
    def get_messages(self, chat_id: Optional[int] = None) -> List[Message]:
        try:
            if chat_id:
                url = f"{self.BASE_URL}/chat/?id={chat_id}"
            else:
                url = f"{self.BASE_URL}/chat/"
            
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'lxml')
            
            messages = []
            message_elements = soup.find_all('div', {'class': 'chat-msg'})
            
            for msg_elem in message_elements:
                author_elem = msg_elem.find('div', {'class': 'chat-msg-author'})
                text_elem = msg_elem.find('div', {'class': 'chat-msg-text'})
                
                if not author_elem or not text_elem:
                    continue
                
                author = author_elem.text.strip()
                text = text_elem.text.strip()
                
                message = Message(
                    text=text,
                    author=author,
                    author_id=0,
                    chat_id=chat_id or 0
                )
                messages.append(message)
            
            return messages
            
        except Exception as e:
            logger.error(f"❌ Ошибка получения сообщений: {e}")
            return []
    
    def send_message(self, chat_id: int, text: str) -> bool:
        try:
            url = f"{self.BASE_URL}/chat/send"
            data = {
                'chat_id': chat_id,
                'text': text
            }
            
            response = self.session.post(url, data=data, timeout=10)
            response.raise_for_status()
            
            logger.info(f"✉️ Сообщение отправлено в чат {chat_id}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка отправки сообщения: {e}")
            return False
    
    def get_orders(self) -> List[Order]:
        try:
            response = self.session.get(f"{self.BASE_URL}/orders/trade", timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'lxml')
            
            orders = []
            order_elements = soup.find_all('a', {'class': 'order-item'})
            
            for order_elem in order_elements:
                order_id_attr = order_elem.get('data-order-id')
                order_id = str(order_id_attr) if order_id_attr else ''
                
                buyer_elem = order_elem.find('div', {'class': 'order-buyer'})
                buyer = buyer_elem.text.strip() if buyer_elem else "Unknown"
                
                desc_elem = order_elem.find('div', {'class': 'order-desc'})
                description = desc_elem.text.strip() if desc_elem else ""
                
                price_elem = order_elem.find('div', {'class': 'order-price'})
                price_text = price_elem.text.strip() if price_elem else "0"
                price = float(''.join(filter(lambda x: x.isdigit() or x == '.', price_text.replace(',', '.'))))
                
                order = Order(
                    order_id=order_id,
                    buyer=buyer,
                    buyer_id=0,
                    description=description,
                    price=price
                )
                orders.append(order)
            
            return orders
            
        except Exception as e:
            logger.error(f"❌ Ошибка получения заказов: {e}")
            return []
    
    def get_user(self, user_id: int):
        """Получить профиль пользователя (для совместимости с плагинами)"""
        logger.debug(f"👤 Получение профиля пользователя {user_id}")
        return {"id": self.user_id, "username": self.username}
    
    def get_lot_fields(self, lot_id: int):
        """Получить поля лота (для совместимости с плагинами)"""
        logger.debug(f"📦 Получение полей лота {lot_id}")
        from .types import LotFields
        
        return LotFields(
            lot_id=lot_id,
            fields={
                'csrf_token': self.csrf_token or '',
                'offer_id': '0'
            }
        )
    
    def save_lot(self, lot):
        """Сохранить лот (создать новый или отредактировать существующий)"""
        try:
            url = f"{self.BASE_URL}/lots/offer/save"
            
            # Готовим данные для отправки
            data = lot.fields.copy() if hasattr(lot, 'fields') else {}
            
            if not data:
                logger.error("❌ Нет данных лота для сохранения")
                return False
            
            logger.debug(f"📤 Отправляю данные лота на {url}")
            response = self.session.post(url, data=data, timeout=15)
            response.raise_for_status()
            
            logger.info(f"✅ Лот успешно сохранен")
            return True
            
        except Exception as e:
            logger.error(f"❌ Ошибка при сохранении лота: {e}")
            logger.debug("TRACEBACK", exc_info=True)
            raise Exception(f"Не удалось сохранить лот: {e}")
    
    @property
    def id(self):
        """Алиас для user_id (для совместимости)"""
        return self.user_id
    
    @property
    def csrf_token(self):
        """CSRF токен (для совместимости с плагинами)"""
        return ""
